---
name: 其他问题（Other issue）
about: 请确认你提出的 issue 不属于「请求帮助」「反馈 bug」或者「提出建议」，否则将有几率被直接关闭。（Make sure your issue is
  not about help wanted, bug report or feature report, or it may be closed directly）

---


